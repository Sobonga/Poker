/*
insert  into planet(planet_id,planet_node,planet_name)
values (1,'A','Earth'),(2,'B','Moon'),(3,'C','Jupiter'),(4,'I"','Gliese 317'),
(5,'J"','HD 38858'),
(6,'K"','Ursae Majoris');


insert  into routes(routes_id,route,planet_origin,planet_destination,distance)
values (1,1,'A','B',0.44),(2,2,'A','C',1.89),(3,3,'A','D',0.10);
*/
